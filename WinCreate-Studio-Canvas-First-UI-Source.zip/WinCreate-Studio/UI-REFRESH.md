# WinCreate Studio — canvas-first UI refresh

This source package builds on the WinCreate Studio repository at https://github.com/VibeXme/WinCreate-Rust--Final. It is not a Windows executable, a repository push, or an official Procreate interface. The design borrows the principle of putting artwork first while retaining WinCreate's native Rust/egui controls.

## What's changed

- A coordinated slate palette, restrained vertex-rendered gradients, consistent type sizes, spacing, hover outlines and selection states.
- Home screen with clear creation action, styled workspace cards, vertical scrolling and single-column stacking below 840 logical pixels.
- Adjustable accent color with four presets, readable accent text and primary-button text even for dark custom colors.
- Appearance settings: compact spacing, corner radius, stronger contrast, gradient toggle and interface scaling.
- Resizable, vertically scrollable tool sidebar and inspector; inspector tabs wrap rather than clipping horizontally.
- Independent visibility controls for tools, inspector and animation timeline.
- Tab toggles focus mode to hide sidebars and timeline. The top workspace controls stay accessible so there is always a way back.
- A shortcut reference in the workspace bar.
- Appearance preferences persist under the existing `ui_preferences` storage key. Older settings remain compatible; missing workspace values receive defaults.

## Source-level fixes

- Home centering now uses a finite viewport height, not the unbounded content height inside a scroll area.
- Plain tool and brush-size shortcuts no longer fire when Command/Ctrl or Alt is held. Text input, the appearance window and pending unsaved-work confirmation suppress global drawing shortcuts.
- Invalid hex color input restores the current valid color and displays feedback.
- Notifications now appear on the home screen as well as the canvas and schedule a repaint at expiry, so they do not linger until the next pointer event.
- Very dark custom accents are lightened for text only; primary buttons use contrasting text.

## Validation status

- Source patches checked against unique exact source fragments.
- Rust syntax checked using rustfmt 1.8.0 from the Rust 1.85.1 distribution; formatting output was not used to rewrite the source.
- Referenced egui 0.31.1 APIs inspected in the published crate source.
- Three Rust unit tests were added for backward-compatible defaults, preference serialization and primary-button text contrast. **They have not been executed.**
- **No complete Cargo build, Windows executable, automated GUI test or visual runtime test has been completed in this environment.** Syntax parsing is not type checking. Compile and test locally before shipping.

## Build and test on Windows

Install the Rust stable toolchain and Visual Studio C++ Build Tools, then open a terminal in the extracted `WinCreate-Studio` directory:

```sh
cargo check --all-targets
cargo test --lib ui::workspace::tests
cargo build --release
```

The Windows executable is expected at `target/release/wincreate-studio.exe` after a successful build. Check the repository's original README for any platform prerequisites.

## Manual acceptance checks before release

1. Launch with existing preferences and with no saved preferences; confirm both open normally.
2. Resize the home window across the single-/two-column breakpoint and scroll to the final content.
3. Try mint, iris, rose, gold, pure black and pure white accents. Confirm active tools and creation buttons remain readable.
4. Toggle density, contrast, gradients, corner radius and scale; close and reopen the app to check persistence.
5. Hide every panel, enter focus mode with Tab, then exit. Confirm controls and artwork remain reachable.
6. Resize both sidebars; select every inspector tab and scroll through all options at a short window height.
7. Type into title and hex fields. Confirm B/E/S/G do not change tools while typing, and invalid hex input gives feedback.
8. Verify Ctrl+S/Open/Export, undo/redo and plain drawing shortcuts; verify unsaved-work confirmation still protects artwork.
9. Draw, erase, smudge, fill, transform, edit layers, animate and export using the original workflows.
10. Trigger an import failure on the home screen and verify its message appears and expires without pointer movement.

## Scope

Drawing algorithms, document formats, image exports and project storage are retained. Existing controls are restyled and reorganized, not replaced with a nonfunctional visual mockup. This pass does not add Procreate's painting engine, gesture system or brush compatibility.
